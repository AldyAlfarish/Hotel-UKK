<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-light text-white bg-dark mx-auto mt-5" style="width: 75%">
        <div class="container-fluid">
          <a class="navbar-brand text-white" href="#">Hotel Hebat</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex ms-auto">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active text-white" aria-current="page" href="/dashboard">Kamar</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-white" aria-current="page">|</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link text-white" href="/fasilitasUmum">Fasilitas Umum</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link text-white">|</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link text-white" href="/fasilitasKamar">Fasilitas Kamar</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link text-white">|</a>
                    </li>
                    <li class="nav-item">
                      <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <a class="text-white nav-link" href="route('logout')"
                                onclick="event.preventDefault();
                                            this.closest('form').submit();">
                            <?php echo e(__('Log Out')); ?>

                        </a>
                    </form>
                    </li>
                  </ul>
                </div>
          </div>
        </div>
      </nav>
    <div style="width: 75%; background: rgb(228 228 231)" class="mx-auto p-5">
        <div class="my-4">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
               Tambah Data
              </button>
        </div>
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Position</th>
                    <th>Office</th>
                    <th>aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->harga); ?></td>
                        <td>
                          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($item->id); ?>">
                              Update
                            </button>
                      </td>
                    </tr>
                    <!-- Modal -->
        <div class="modal fade" id="exampleModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Update Data</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      <form action="/updatekmr/<?php echo e($item->id); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Nama Kamar</label>
                            <input type="text" name="nama" value="<?php echo e($item->nama); ?>" class="form-control">
                          </div>
                          <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Harga</label>
                            <input type="text" name="harga" value="<?php echo e($item->harga); ?>" class="form-control" >
                          </div>
                          <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                  </div>
                  <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  </div>
              </div>
          </div>
      </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/tambahkamar" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                              <label for="exampleInputEmail1" class="form-label">Nama Kamar</label>
                              <input type="text" name="nama" class="form-control">
                            </div>
                            <div class="mb-3">
                              <label for="exampleInputPassword1" class="form-label">Harga</label>
                              <input type="text" name="harga" class="form-control" >
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                          </form>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hotel-app\resources\views/admin/kamar.blade.php ENDPATH**/ ?>