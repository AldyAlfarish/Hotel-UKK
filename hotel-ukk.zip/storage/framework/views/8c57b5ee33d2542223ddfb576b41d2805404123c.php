<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <div id="materiCetak" class="fixed top-0 left-0 w-full h-full bg-white hidden" style="z-index: 100">
                        
    </div>
    
    <nav class="bg-white w-3/4 mt-5 mb-3 mx-auto border-gray-200 px-2 sm:px-4 py-2.5 rounded dark:bg-gray-900">
        <div class="container flex flex-wrap items-center justify-between mx-auto">
        <a href="#" class="flex items-center">
            <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Hotel Hebat</span>
        </a>
        <button data-collapse-toggle="navbar-default" type="button" class="inline-flex items-center p-2 ml-3 text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
        </button>
        <div class="hidden w-full md:block md:w-auto" id="navbar-default">
            <ul class="flex flex-col p-4 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                <li>
                    <a href="/" class="block py-2 pl-3 pr-4 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 dark:text-white" aria-current="page">Home</a>
                </li>
                <li>
                    <a href="/fasilitasKmr" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Kamar</a>
                </li>
                <li>
                    <a href="/umum" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Fasilitas</a>
                </li>
            </ul>
        </div>
        </div>
    </nav>
    <div class="mx-auto w-3/4">
        <img src="assets/b.jpg" width="100%">
    </div>
    <div class="w-3/4 mx-auto mt-5 mb-4">
        <form action="/insert" method="POST" id="form">
            <?php echo csrf_field(); ?>
            <div class="grid gap-6 mb-6 md:grid-cols-4">
                <div>
                    <label for="first_name" class="block mb-2 text-sm font-medium text-gray-900">Tanggal Check In</label>
                    <input type="date" id="checkIn" name="check_in" class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:border-gray-600 dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                <div>
                    <label for="last_name" class="block mb-2 text-sm font-medium text-gray-900">Tanggal Check Out</label>
                    <input type="date" id="checkOut" name="check_out" class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:border-gray-600 dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                <div>
                    <label for="company" class="block mb-2 text-sm font-medium text-gray-900">Jumlah Kamar</label>
                    <input type="number" id="jumlah" name="jumlah" class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:border-gray-600 dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>  
                <div>
                    <button onclick="pesan()" class="bg-blue-500 rounded-md w-1/2 h-10 text-white mt-7 font-medium">Pesan</button>
                </div>  
            </div>
            <div class="mt-3 w-1/2 mx-auto" id="pemesanan" hidden>
                <div class="flex mb-3">
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 p-2.5">Nama Pemesan</label>
                    <input type="text" id="namaPemesan" name="nama_pemesan" style="margin-left: 50px"  class="bg-gray-50 w-1/2 border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="john.doe@company.com" required>
                </div>
                <div class="flex mb-3">
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 p-2.5">Email Pemesan</label>
                    <input type="email" id="email" name="email" style="margin-left: 54px"  class="bg-gray-50 w-1/2 border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="john.doe@company.com" required>
                </div>
                <div class="flex mb-3">
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 p-2.5">Nomor Handphone</label>
                    <input type="text" id="hp" name="hp_pemesan" class="bg-gray-50 w-1/2 ml-6 border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="john.doe@company.com" required>
                </div>
                <div class="flex mb-3">
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 p-2.5">Nama Tamu</label>
                    <input type="text" id="namaTamu" name="nama_tamu" style="margin-left: 75px" class="bg-gray-50 w-1/2 ml-6 border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="john.doe@company.com" required>
                </div>
                <div class="flex">
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 p-2.5">Tipe Kamar</label>
                    <select name="kamar_id" id="tipe" style="margin-left: 75px" class="bg-gray-50 w-1/2 ml-6 border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 text-black dark:focus:ring-blue-500 dark:focus:border-blue-500" required >
                        <?php $__currentLoopData = $kmr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?> <?php echo e($item->harga); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </select>
                </div>
                <div class="ml-80">
                    <button onclick="konfirmasi()" class="bg-blue-500 rounded-md w-32 h-10 text-white mt-7 font-medium">Kirim</button>
                </div>
            </div>
        </form>
        

    </div>
    <!-- Bagian Banner ############################################################# -->
    
    <!-- ................................................................................... -->




    <!-- Bagian Input ############################################################# -->
    
    <!-- ................................................................................... -->




    <!-- Bagian Text Deskripsi ############################################################# -->
    <div id="deskripsi" style="width: 75%; text-align: center; margin-left: auto; margin-right: auto;">
        <h1>Tentang Kami</h1>
        <h4 style="text-align: justify; font-weight: lighter; ">Lepaskan diri anda ke Hotel Hebat, dikelilingi oleh keindahan pegunungan yang indah, danau, dan sawah menghijau. Nikmati sore yang hangat dengan berenang di kolam renang dengan pemandangan matahari terbenam yang memukau; Kid's Club yang luas - menawarkan beragam fasilitas dan kegiatan anak-anak yang akan melengkapi kenyamanan keluarga. Convention Center kami, dilengkapi pelayanan lengkap dengan ruang konvensi terbesar di Bandung, mampu mengakomodasi hingga 3.000 delegasi. Manfaatkan ruang penyelenggaraan konvensi M.I.C.E ataupun mewujudkan acara pernikahan adat yang mewah.</h4>
    </div>
    <!-- ................................................................................... -->




    <!-- Bagian Form Pemesanan ############################################################# -->
    
    <!-- ................................................................................... -->




    <!-- Bagian Script ############################################################# -->
    <script>
        function cetak() {
            // alert(document.getElementById('email').value);
                    document.getElementById('materiCetak').classList.toggle('hidden');
                    const printData = document.getElementById('namaPemesan').value;
                    const printContainer = document.getElementById("materiCetak");
                    const newParagraph = document.createElement("p");
                    newParagraph.textContent = printData;
                    printContainer.appendChild(newParagraph);
                    print(document.getElementById('materiCetak').innerHTML);
                    document.getElementById('form').submit();
                }
        // function cetak() {

        //     document.getElementById('daftar').style.display = "none";
        //     document.getElementById('delete-modal-preview').style.display = "none";
        //     document.getElementById('view').style.height = "fit-content";
        //     document.getElementById('view').style.visibility = "visible";
        //     document.getElementById('page').innerHTML = '';
        //     pilihan.forEach(element => {
        //         document.getElementById('page').innerHTML += '<div>'+element.nm.split(' ')[0]+'</div>';
        //         // document.getElementById('page').innerHTML += "<p>"+element.jabatan+"</p>";
        //         // document.getElementById('page').innerHTML += "<p>"+element.daerah+"</p>";
        //         // document.getElementById('page').innerHTML += '<div style="font-weight: bold; font-size: 20px;">'+element.no+'</div>';
        //     });
        //     print(document.getElementById('page').innerHTML);


        //     document.getElementById('form').submit();
        // }
        function pesan()
        {
            document.getElementById('deskripsi').hidden = !document.getElementById('deskripsi').hidden;
            document.getElementById('pemesanan').hidden = !document.getElementById('pemesanan').hidden;
        }
        function konfirmasi()
        {
            var a = window.open('', '', 'height=500, width=500');
            a.document.write('<html>');
            a.document.write('<body ><h1>Bukti Reservasi</h1>');
            a.document.write('<body ><h3>Detail Reservasi:</h3>');
            // a.document.write(document.getElementById('pemesanan').innerHTML);
            a.document.write('<h3>Nama Pemesan:'+document.getElementById('namaPemesan').value+'</h3>');
            a.document.write('<h3>Email:'+document.getElementById('email').value+'</h3>');
            a.document.write('<h3>Jumlah Kamar:'+document.getElementById('jumlah').value+'</h3>');
            a.document.write('<h3>Tanggal Check In:'+document.getElementById('checkIn').value+'</h3>');
            a.document.write('<h3>Tanggal Check Out:'+document.getElementById('checkOut').value+'</h3>');
            a.document.write('</body></html>');
            a.document.close();
            a.print();
            document.getElementById('form').submit();
        }
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hotel-app\resources\views/dashboard.blade.php ENDPATH**/ ?>