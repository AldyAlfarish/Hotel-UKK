<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReservasiModel extends Model
{
    use HasFactory;
    protected $table = 'reservasi';
    protected $primaryKey = 'id';
    protected $fillable = [
        'nama_pemesan',
        'email',
        'hp_pemesan',
        'nama_tamu',
        'kamar_id',
        'jumlah',
        'check_in',
        'check_out',
        'status',
    ];


}
