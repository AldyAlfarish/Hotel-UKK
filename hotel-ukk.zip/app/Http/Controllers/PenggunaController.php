<?php

namespace App\Http\Controllers;

use App\Models\FasilitasKamarModel;
use App\Models\FasilitasUmumModel;
use App\Models\KamarModel;
use App\Models\ReservasiModel;
use Illuminate\Http\Request;

class PenggunaController extends Controller
{
    public function index()
    {
        $kmr = KamarModel::all();
        return view('dashboard', compact('kmr'));
    }
    public function kamar()
    {
        $data = FasilitasKamarModel::all();
        return view('fasilitasKamar', compact('data'));
    }
    public function umum()
    {
        $data = FasilitasUmumModel::all();
        return view('fasilitasUmum', compact('data'));
    }
    public function insert(Request $request)
    {
        ReservasiModel::create([
            'nama_pemesan' => $request->nama_pemesan,
            'email' => $request->email,
            'hp_pemesan' => $request->hp_pemesan,
            'nama_tamu' => $request->nama_tamu,
            'kamar_id' => $request->kamar_id,
            'jumlah' => $request->jumlah,
            'check_in' => $request->check_in,
            'check_out' => $request->check_out,
            'status' => 'Belum Check In',
        ]);

        return redirect()->back();
    }
}
