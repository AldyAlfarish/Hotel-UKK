<?php

namespace App\Http\Controllers;

use App\Models\ReservasiModel;
use Illuminate\Http\Request;

class ResepsionisController extends Controller
{
    public function index()
    {
        $data = ReservasiModel::get();

        return view('resepsionis', compact('data'));
    }
    public function update($id)
    {
        ReservasiModel::where('id', '=', $id)->update([
            'status' => 'Check In',
        ]);
        return redirect()->back();
    }
}
