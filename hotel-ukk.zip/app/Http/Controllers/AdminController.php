<?php

namespace App\Http\Controllers;

use App\Models\FasilitasKamarModel;
use App\Models\FasilitasUmumModel;
use App\Models\KamarModel;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function kamar()
    {
        $data = KamarModel::all();
        return view('admin.kamar', compact('data'));
    }
    public function tambahkamar(Request $request)
    {
        KamarModel::create([
            'nama' => $request->nama,
            'harga' => $request->harga,
        ]);
        return redirect()->back();
    }
    public function updatekmr(Request $request, $id)
    {
        KamarModel::where('id', '=', $id)
        ->update([
            'nama' => $request->nama,
            'harga' => $request->harga,
        ]);
        return redirect()->back();
    }

    public function fasilitasKamar()
    {
        $data = FasilitasKamarModel::all();
        return view('admin.fasilitasK', compact('data'));
    }
    public function addfasilitasKamar(Request $request)
    {
        $request->validate([
            'foto' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $imageName = $request->tipe.'.'.$request->foto->extension();


        $path = $request->file('foto')->storeAs(
            'public/fasilitasKamar', $imageName
        );
        FasilitasKamarModel::create([
            'tipe' => $request->tipe,
            'fasilitas' => $request->fasilitas,
            'foto' => $imageName,
        ]);
        return redirect()->back();
    }
    public function updateFk(Request $request, $id)
    {
        $request->validate([
            'foto' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $imageName = $request->tipe.'.'.$request->foto->extension();


        $path = $request->file('foto')->storeAs(
            'public/fasilitasKamar', $imageName
        );
        FasilitasKamarModel::where('id', '=', $id)
        ->update([
            'tipe' => $request->tipe,
            'fasilitas' => $request->fasilitas,
            'foto' => $imageName,
        ]);
        return redirect()->back();
    }
    

    public function fasilitasUmum()
    {
        $data = FasilitasUmumModel::all();
        return view('admin.fasilitasU', compact('data'));
    }
    public function addfasilitasUmum(Request $request)
    {
        $request->validate([
            'foto' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $imageName = $request->nama.'.'.$request->foto->extension();


        $path = $request->file('foto')->storeAs(
            'public/fasilitasUmum', $imageName
        );
        FasilitasUmumModel::create([
            'nama' => $request->nama,
            'fasilitas' => $request->fasilitas,
            'foto' => $imageName,

        ]);
        return redirect()->back();
    }
    public function updateFU(Request $request, $id)
    {
        $request->validate([
            'foto' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $imageName = $request->nama.'.'.$request->foto->extension();


        $path = $request->file('foto')->storeAs(
            'public/fasilitasUmum', $imageName
        );
        FasilitasUmumModel::where('id', '=', $id)
        ->update([
            'nama' => $request->nama,
            'fasilitas' => $request->fasilitas,
            'foto' => $imageName,
        ]);
        return redirect()->back();
    }
}
