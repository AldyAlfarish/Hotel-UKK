-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2023 at 05:50 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fasilitas_kamar`
--

CREATE TABLE `fasilitas_kamar` (
  `id` int(11) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `fasilitas` varchar(1000) NOT NULL,
  `foto` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fasilitas_kamar`
--

INSERT INTO `fasilitas_kamar` (`id`, `tipe`, `fasilitas`, `foto`, `created_at`, `updated_at`) VALUES
(1, 'Superior', 'TV 32 Inch', 'Superior.jpg', '2023-03-14 13:57:04', '2023-03-14 21:13:16'),
(2, 'Superior', 'Big Bed', 'Superior.jpg', '2023-03-14 13:57:04', '2023-03-14 21:13:30'),
(3, 'Superior', 'Hot Water Shower', 'Superior.jpg', '2023-03-14 13:57:04', '2023-03-14 21:13:40'),
(4, 'Superior', 'Bath Tube', 'Superior.jpg', '2023-03-14 13:57:04', '2023-03-14 21:13:55'),
(5, 'ncbmzcbzxm', 'jdkjhs', 'ncbmzcbzxm.jpg', '2023-03-14 07:14:51', '2023-03-14 21:14:29');

-- --------------------------------------------------------

--
-- Table structure for table `fasilitas_umum`
--

CREATE TABLE `fasilitas_umum` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(500) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fasilitas_umum`
--

INSERT INTO `fasilitas_umum` (`id`, `nama`, `foto`, `fasilitas`, `created_at`, `updated_at`) VALUES
(1, 'lorem ipsum lorem ipsum', 'lorem ipsum lorem ipsum.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae eos esse ducimus consequatur modi sunt, facilis dicta qui quibusdam reprehenderit aut dolorem temporibus nisi asperiores delectus voluptates! Quod, numquam id!', '2023-03-14 08:24:31', '2023-03-14 21:15:32'),
(4, 'Lorem Ipsum', 'Lorem Ipsum.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae eos esse ducimus consequatur modi sunt, facilis dicta qui quibusdam reprehenderit aut dolorem temporibus nisi asperiores delectus voluptates! Quod, numquam id!', '2023-03-14 21:15:53', '2023-03-14 21:15:53');

-- --------------------------------------------------------

--
-- Table structure for table `kamar`
--

CREATE TABLE `kamar` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kamar`
--

INSERT INTO `kamar` (`id`, `nama`, `harga`, `created_at`, `updated_at`) VALUES
(3, 'Superior', 800000, '2023-03-14 13:49:23', '2023-03-14 13:49:23'),
(4, 'Deluxe', 500000, '2023-03-14 13:49:23', '2023-03-14 13:49:23'),
(5, 'sunda', 10000, '2023-03-14 06:49:27', '2023-03-14 08:32:45');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservasi`
--

CREATE TABLE `reservasi` (
  `id` int(11) NOT NULL,
  `nama_pemesan` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `hp_pemesan` varchar(255) NOT NULL,
  `nama_tamu` varchar(255) NOT NULL,
  `kamar_id` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `check_in` date NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `check_out` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservasi`
--

INSERT INTO `reservasi` (`id`, `nama_pemesan`, `email`, `hp_pemesan`, `nama_tamu`, `kamar_id`, `jumlah`, `check_in`, `status`, `check_out`, `created_at`, `updated_at`) VALUES
(1, 'hgh', 'erwindwikap@umb.ac.id', '687', 'mznczfk', 3, 6, '2023-03-14', 'Check In', '2023-03-16', '2023-03-14 03:38:45', '2023-03-14 05:39:31'),
(2, 'ffe', 'erwindwikap@umb.ac.id', '92982', 'sadasd', 4, 7, '2023-03-15', 'Check In', '2023-03-18', '2023-03-14 03:46:46', '2023-03-14 05:39:44'),
(3, 'wewefw', 'admin@gm.com', '92982', 'bcckja', 3, 2, '2023-03-16', 'Check In', '2023-04-07', '2023-03-14 03:48:26', '2023-03-14 05:41:00'),
(4, 'wdwe', 'adm@gmail.com', '232', 'sdxsd', 3, 1, '2023-03-21', NULL, '2023-03-29', '2023-03-14 03:54:05', '2023-03-14 03:54:05'),
(5, 'jdkasjdlkajs', 'adm@gmail.com', '675765765', 'gfdrdr', 3, 2, '2023-03-29', NULL, '2023-03-31', '2023-03-14 04:03:41', '2023-03-14 04:03:41'),
(6, '[object HTMLParagraphElement]', 'yy@gmail.com', '98798798', 'khkjfhk', 3, 8, '2023-03-23', NULL, '2023-03-15', '2023-03-14 04:11:29', '2023-03-14 04:11:29'),
(7, 'hgjhgjh', 'lorem@il.com', '8687687', 'ghhfhg', 3, 3, '2023-03-15', NULL, '2023-03-17', '2023-03-14 04:13:38', '2023-03-14 04:13:38'),
(8, 'xnzvbmzbm', 'erwindwikap@umb.ac.id', '3453453', 'sfsdfs', 3, 3, '2023-04-05', NULL, '2023-04-07', '2023-03-14 04:15:12', '2023-03-14 04:15:12'),
(9, 'jdhkjdhfk', 'sdm@gmail.com', '98978988', 'nmbmbm', 3, 3, '2023-03-22', NULL, '2023-03-24', '2023-03-14 04:17:42', '2023-03-14 04:17:42'),
(10, 'ffe', 'adm@gmail.com', '5', 'rrterte', 3, 3, '2023-03-30', NULL, '2023-03-31', '2023-03-14 04:18:56', '2023-03-14 04:18:56'),
(11, 'xnzvbmzbm', 'hgjhg@gmail.com', '324768236', 'hjgdjgdj', 3, 65, '2023-03-14', NULL, '2023-03-17', '2023-03-14 04:28:51', '2023-03-14 04:28:51'),
(12, 'sayya', 'sayyy@gm', '3298237498', 'fhkjfhkjhf', 4, 2, '2023-03-14', NULL, '2023-03-16', '2023-03-14 05:03:07', '2023-03-14 05:03:07'),
(13, 'jhfkdjshfks', 'aldy@umb.ac.id', '4234234', 'sdfdfs', 3, 1, '2023-03-14', NULL, '2023-03-16', '2023-03-14 05:04:18', '2023-03-14 05:04:18'),
(14, 'aldy', 'al@gmail.com', '9284928492', 'skdjfhdj', 3, 1, '2023-03-14', NULL, '2023-03-17', '2023-03-14 05:10:00', '2023-03-14 05:10:00'),
(15, 'asdfg', 'ald6@gmail.com', '34983247923', 'sunda', 3, 6, '2023-03-14', NULL, '2023-03-17', '2023-03-14 05:11:54', '2023-03-14 05:11:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('admin','resepsionis') DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `role`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', NULL, '$2a$12$Iaay1EqdTI0k6S/EmH4mTec2aQh2kf6z3qSlp/0ga4V0/Bk4cAT1.', NULL, '2023-03-13 19:39:06', '2023-03-13 19:39:06'),
(2, 'resepsionis', 'resepsionis@gmail.com', 'resepsionis', NULL, '$2a$12$Iaay1EqdTI0k6S/EmH4mTec2aQh2kf6z3qSlp/0ga4V0/Bk4cAT1.', NULL, '2023-03-13 19:39:06', '2023-03-13 19:39:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fasilitas_kamar`
--
ALTER TABLE `fasilitas_kamar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fasilitas_umum`
--
ALTER TABLE `fasilitas_umum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kd_kamar` (`kamar_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fasilitas_kamar`
--
ALTER TABLE `fasilitas_kamar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fasilitas_umum`
--
ALTER TABLE `fasilitas_umum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservasi`
--
ALTER TABLE `reservasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD CONSTRAINT `reservasi_ibfk_2` FOREIGN KEY (`kamar_id`) REFERENCES `kamar` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
